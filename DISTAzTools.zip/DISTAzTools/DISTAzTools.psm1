#
#
#

. $PSScriptRoot\Test-DISTAzChocolatey.ps1
. $PSScriptRoot\Get-DISTAzVMPubIP.ps1
. $PSScriptRoot\Install-DISTAzAllTools.ps1
. $PSScriptRoot\Install-DISTAzChocolatey.ps1
. $PSScriptRoot\Install-DISTAzAZCLI.ps1
. $PSScriptRoot\Install-DISTAzBrowsers.ps1
. $PSScriptRoot\Install-DISTAzGit.ps1
. $PSScriptRoot\Install-DISTAzPowerShellCore.ps1
. $PSScriptRoot\Install-DISTAzAzModules.ps1
. $PSScriptRoot\Install-DISTAzStorageExplorer.ps1
. $PSScriptRoot\Install-DISTAzVSCode.ps1
. $PSScriptRoot\Install-DISTAzVSCodeExtension.ps1
