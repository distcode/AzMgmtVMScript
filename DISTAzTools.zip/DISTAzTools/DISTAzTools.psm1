#
#
#

. $PSScriptRoot\Install-DISTAzVSCodeExtension.ps1
. $PSScriptRoot\Get-DISTAzVMPubIP.ps1
